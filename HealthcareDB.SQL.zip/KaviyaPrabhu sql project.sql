-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: healthcaredb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `appointment_id` int NOT NULL,
  `patient_id` int DEFAULT NULL,
  `doctor_id` int DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `patient_id` (`patient_id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (301,201,101,'2026-02-01','Completed'),(302,202,102,'2026-02-02','Completed'),(303,203,103,'2026-02-03','Pending'),(304,204,104,'2026-02-04','Completed'),(305,205,105,'2026-02-05','Pending'),(306,206,106,'2026-02-06','Completed'),(307,207,107,'2026-02-07','Completed'),(308,208,108,'2026-02-08','Pending'),(309,209,109,'2026-02-09','Completed'),(310,210,110,'2026-02-10','Completed'),(311,211,101,'2026-02-11','Pending'),(312,212,102,'2026-02-12','Completed'),(313,213,103,'2026-02-13','Completed'),(314,214,104,'2026-02-14','Pending'),(315,215,105,'2026-02-15','Completed'),(316,216,106,'2026-02-16','Completed'),(317,217,107,'2026-02-17','Pending'),(318,218,108,'2026-02-18','Completed'),(319,219,109,'2026-02-19','Completed'),(320,220,110,'2026-02-20','Pending'),(321,201,101,'2026-03-01','Pending');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billing`
--

DROP TABLE IF EXISTS `billing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing` (
  `bill_id` int NOT NULL,
  `patient_id` int DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT NULL,
  `bill_date` date DEFAULT NULL,
  PRIMARY KEY (`bill_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `billing_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing`
--

LOCK TABLES `billing` WRITE;
/*!40000 ALTER TABLE `billing` DISABLE KEYS */;
INSERT INTO `billing` VALUES (401,201,5000.00,'Paid','2026-02-01'),(402,202,4500.00,'Paid','2026-02-02'),(403,203,6000.00,'Paid','2026-02-03'),(404,204,7000.00,'Paid','2026-02-04'),(405,205,3500.00,'Pending','2026-02-05'),(406,206,8000.00,'Paid','2026-02-06'),(407,207,5200.00,'Paid','2026-02-07'),(408,208,6100.00,'Pending','2026-02-08'),(409,209,4800.00,'Paid','2026-02-09'),(410,210,5500.00,'Paid','2026-02-10'),(411,211,7200.00,'Pending','2026-02-11'),(412,212,6400.00,'Paid','2026-02-12'),(413,213,5300.00,'Paid','2026-02-13'),(414,214,5800.00,'Pending','2026-02-14'),(415,215,6700.00,'Paid','2026-02-15'),(416,216,4500.00,'Paid','2026-02-16'),(417,217,3900.00,'Pending','2026-02-17'),(418,218,4100.00,'Paid','2026-02-18'),(419,219,7600.00,'Paid','2026-02-19'),(420,220,5000.00,'Pending','2026-02-20'),(421,201,8500.00,'Paid','2026-02-25'),(423,201,7500.00,'Pending','2026-03-01'),(430,201,7000.00,'Pending','2026-03-05');
/*!40000 ALTER TABLE `billing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `dept_id` int NOT NULL,
  `dept_name` varchar(50) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'Cardiology','Block A'),(2,'Neurology','Block B'),(3,'Orthopedics','Block C'),(4,'Dermatology','Block D'),(5,'Pediatrics','Block E');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `doctor_id` int NOT NULL,
  `doctor_name` varchar(50) DEFAULT NULL,
  `specialization` varchar(50) DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  PRIMARY KEY (`doctor_id`),
  KEY `dept_id` (`dept_id`),
  CONSTRAINT `doctor_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (101,'Dr.Ravi','Cardiologist',1),(102,'Dr.Anitha','Neurologist',2),(103,'Dr.Kumar','Orthopedic',3),(104,'Dr.Priya','Dermatologist',4),(105,'Dr.Suresh','Pediatrician',5),(106,'Dr.Manoj','Cardiologist',1),(107,'Dr.Divya','Neurologist',2),(108,'Dr.Karthik','Orthopedic',3),(109,'Dr.Deepika','Dermatologist',4),(110,'Dr.Ramesh','Pediatrician',5);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `healthcare_report_view`
--

DROP TABLE IF EXISTS `healthcare_report_view`;
/*!50001 DROP VIEW IF EXISTS `healthcare_report_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `healthcare_report_view` AS SELECT 
 1 AS `patient_name`,
 1 AS `doctor_name`,
 1 AS `dept_name`,
 1 AS `total_amount`,
 1 AS `payment_status`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `patient_id` int NOT NULL,
  `patient_name` varchar(50) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (201,'Kaviya',22,'Female','9876500001','Chennai'),(202,'Prabhu',30,'Male','9876500002','Salem'),(203,'Sandhiya',25,'Female','9876500003','Madurai'),(204,'Yuvaraj',32,'Male','9876500004','Trichy'),(205,'Mangalesh',28,'Male','9876500005','Coimbatore'),(206,'Selvi',40,'Female','9876500006','Erode'),(207,'Vindhiya',27,'Female','9876500007','Chennai'),(208,'Sushmitha',24,'Female','9876500008','Salem'),(209,'Viji',35,'Female','9876500009','Madurai'),(210,'Lincy',29,'Female','9876500010','Trichy'),(211,'Yoga',26,'Female','9876500011','Chennai'),(212,'Arasu',38,'Male','9876500012','Salem'),(213,'Rahul',31,'Male','9876500013','Coimbatore'),(214,'Meena',33,'Female','9876500014','Erode'),(215,'Arun',36,'Male','9876500015','Madurai'),(216,'Divya',23,'Female','9876500016','Chennai'),(217,'Karthik',34,'Male','9876500017','Trichy'),(218,'Anu',21,'Female','9876500018','Salem'),(219,'Sathish',39,'Male','9876500019','Coimbatore'),(220,'Deepa',28,'Female','9876500020','Erode');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prescription` (
  `prescription_id` int NOT NULL,
  `appointment_id` int DEFAULT NULL,
  `medicine_name` varchar(100) DEFAULT NULL,
  `dosage` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`prescription_id`),
  KEY `appointment_id` (`appointment_id`),
  CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`appointment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription`
--

LOCK TABLES `prescription` WRITE;
/*!40000 ALTER TABLE `prescription` DISABLE KEYS */;
INSERT INTO `prescription` VALUES (501,301,'Paracetamol','500mg'),(502,302,'Amoxicillin','250mg'),(503,303,'Ibuprofen','400mg'),(504,304,'Cetirizine','10mg'),(505,305,'Metformin','500mg'),(506,306,'Aspirin','75mg'),(507,307,'Azithromycin','500mg'),(508,308,'Pantoprazole','40mg'),(509,309,'Atorvastatin','10mg'),(510,310,'Losartan','50mg'),(511,311,'Omeprazole','20mg'),(512,312,'Dolo','650mg'),(513,313,'Vitamin D','1000IU'),(514,314,'Calcium','500mg'),(515,315,'Insulin','10 units'),(516,316,'Cough Syrup','10ml'),(517,317,'Antacid','5ml'),(518,318,'Diclofenac','50mg'),(519,319,'Montelukast','10mg'),(520,320,'Levocetirizine','5mg');
/*!40000 ALTER TABLE `prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `healthcare_report_view`
--

/*!50001 DROP VIEW IF EXISTS `healthcare_report_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `healthcare_report_view` AS select `p`.`patient_name` AS `patient_name`,`d`.`doctor_name` AS `doctor_name`,`dept`.`dept_name` AS `dept_name`,`b`.`total_amount` AS `total_amount`,`b`.`payment_status` AS `payment_status` from ((((`patient` `p` join `appointment` `a` on((`p`.`patient_id` = `a`.`patient_id`))) join `doctor` `d` on((`a`.`doctor_id` = `d`.`doctor_id`))) join `department` `dept` on((`d`.`dept_id` = `dept`.`dept_id`))) join `billing` `b` on((`p`.`patient_id` = `b`.`patient_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-09 12:15:17
